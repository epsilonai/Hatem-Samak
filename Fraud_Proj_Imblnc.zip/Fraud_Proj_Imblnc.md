# Frauad model_Imbalancing

## Pre-processing Data
https://towardsdatascience.com/methods-for-dealing-with-imbalanced-data-5b761be45a18


```python
#Import Libararies
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
%matplotlib inline

# import warnings filter
# from warnings import simplefilter

# ignore all future warnings
# simplefilter(action='ignore', category=FutureWarning)

# check scikit-learn version
# print('sklearn: %s' % sklearn.__version__)
```


```python
#Read dataset
url="/mnt/1A746F7B746F5891/L U N I X/Machine learning/Final Project/Creditcardfraud/Dataset/creditcardfraud/creditcard.csv"
dataset=pd.read_csv(url)

#Display head of dataset
dataset.head()

#split into dataset_X and dataset_y
dataset_X=dataset.drop(["Time","Class"],axis=1)# Must Write axis=1
dataset_y=dataset.Class
```


```python
print(len(dataset_X),len(dataset_y),len(dataset))
```

    284807 284807 284807



```python
#Draw the corrlation and covariance

figure=plt.figure(figsize=(14,10))
plt.matshow(dataset.corr(),fignum=figure.number)
plt.xticks(range(dataset.shape[1]),dataset.columns,fontsize=10,rotation=45)
plt.yticks(range(dataset.shape[1]),dataset.columns,fontsize=10)
colorbar=plt.colorbar()
colorbar.ax.tick_params(labelsize=14)
plt.title("Correlation Matrix", fontsize=16)
plt.show
# #Get corrleation, Covar
# dataset.corr(), dataset.cov()
```




    <function matplotlib.pyplot.show(*args, **kw)>




![png](output_5_1.png)



```python
#check if there any data Nan
# dataset.isnull().sum()

# #check the type of features
# dataset.dtypes ,dataset.describe()
```


```python
#check imbalancing data
unfruad_count=dataset.Class[dataset.Class==0].count()
fruad_count=dataset.Class[dataset.Class==1].count()
percent_unfruad=unfruad_count/(unfruad_count+fruad_count)
print("The percentag of unfruad is : %3f" % percent_unfruad,fruad_count)
```

    The percentag of unfruad is : 0.998273 492


# Data Is Imbalance
##continue with raw dataset no 

## Determine which feature we will delete


```python

```


```python
#Split dataset to train and test 
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test \
        = train_test_split(dataset_X,dataset_y, test_size=0.2,\
        stratify=dataset_y, random_state=123, shuffle=True)
```


```python
#check distribution of fraud instance on all file
# fraud_train=y_train.Class[y_train.Class==1].count()
count_trn=0
count_tst=0
all_trn=0
all_tst=0
for i in y_train :
    all_trn+=1
    if i==1:
        count_trn+=1
for j in y_test:
    all_tst+=1
    if j==1:
        count_tst+=1
print(all_trn,count_trn,all_tst,count_tst,count_trn+count_tst)
```

    227845 394 56962 98 492


# implement Recursive Feature Elimination RFE


```python
#import library
# from sklearn.feature_selection import RFE
from sklearn.linear_model import LogisticRegression

logistic = LogisticRegression(random_state = 0)
# rfe=RFE(logistic,20)# Where 4 is the top features
# rfe.fit(X_train,y_train)
# print('selected Feature: %s'%(rfe.fit(X_train,y_train).support_))
# print("Feature Ranking: %s"%(rfe.fit(X_train,y_train).ranking_))
logistic.fit(X_train, y_train)
```




    LogisticRegression(C=1.0, class_weight=None, dual=False, fit_intercept=True,
                       intercept_scaling=1, l1_ratio=None, max_iter=100,
                       multi_class='warn', n_jobs=None, penalty='l2',
                       random_state=0, solver='warn', tol=0.0001, verbose=0,
                       warm_start=False)



## Evaluate the LR module

##using Confusion matrix



```python
from sklearn.metrics import confusion_matrix
cm = confusion_matrix(y_test, logistic.predict(X_test))
pd.DataFrame(cm)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>0</th>
      <th>1</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>56854</td>
      <td>10</td>
    </tr>
    <tr>
      <th>1</th>
      <td>42</td>
      <td>56</td>
    </tr>
  </tbody>
</table>
</div>



## Evaluate Accuracy


```python
lgsc=logistic.score(y_test, logistic.predict(X_test))
print("Accuracy of using Logistic Reg model is :%.2f"%lgsc)
print("Probaility: {}".format(np.unique(logistic.predict(X_test))))
```

# Metric using AUROC


```python
#use Area Under ROC Curve (AUROC)
#it calculate probability that the model will be able to "rank" 
#correctly if we rondomly select one observation from each class

# we will need to predict class probalilityes instead of just the predicted classes using
# .predict_proba()
from sklearn.metrics import roc_auc_score

prob_y=logistic.predict_proba(X_test)

#Keep only the positive class
prob_y=[p[1] for p in prob_y]

print(prob_y[:5])

#AUROC of model trained on downsampled dataset
print("\n","Metrices using AUROC is : %.2f"%roc_auc_score(y_test,prob_y),"\n")

#we can do thin on original model befor apply the technique and compare the results

# datase_y=clf_0.prdict_proba(X)

# #keep only the positive class
# prob_y_0=clf_0.predict_proba()
# prob_y_0=[p[1] for p in prob_y_0]

# # get the score
# print(roc_auc_score(y, prob_y_0))

print("Probaility: {}".format(np.unique(logistic.predict_proba(X_test))))

# predictions=pd.Dataframe(predicted_data)# to transfer array to DataFrame
# predictions[0].value_counts() # get the count of each classifier (0,1)



```

    [7.174881820042209e-05, 0.00020412503594656068, 0.00029858344287108214, 0.00028651193693128167, 0.0011695622783155118]
    
     Metrices using AUROC is : 0.96 
    
    Probaility: [5.89755057e-13 2.99768292e-12 3.15728647e-12 ... 1.00000000e+00
     1.00000000e+00 1.00000000e+00]


## Penalize Algorithms (Cost-Sensitive Training)


```python
# during training we can use the argument class_weitht="balanced" to penalize mistake on the 
# minority class by an amount proportional to how under-represented is
# we also will inclode the argument probability="True"

#Separate input features (X) and target (y)


#Train model
clf_3=SVC(kernel="linear", class_weight="balanced", # penalize
         probability=True)

clf_3.fit(X_train,y_train)

#predict on test set
pred_y_3=clf_3.predict(X_test)

#check if predict one class of two
print("Probaility: {}".format(np.unique(prob_y_3)))
# Calculate accuracy
print(accuracy_score(y_test,pred_y_3))

#Calculate AUROC metric
prob_y_3=clf_3.predict_proba(X_test)

# prob_y_3=[p[1] for p in prob_y_3]
# print (roc_auc_score(y_test,prob_y_3))
```

## Use Tree-Based Algorithms


```python
from sklearn.ensemble import RandomForestClassifier
```


```python
# Train model
clf_RFCls=RandomForestClassifier()
clf_RFCls.fit(X_train,y_train)

#Predict on test set
pred_y_RFCls=clf_RFCls.predic(X_test)

#check if we predict from the two classes or not
print(np.unique(pred_y_RFCls))

# #get accurcy
# print(accuracy_score(y_test,pred_y_RFCls))

#calcualte the AUROC
pred_y_RFCls=clf_RFCls.predict_proba(X_test)

# pred_y_RFCls=[p[1] for p in prob_y_4]
# print (roc_auc_score(y_test,prob_y_4))
```


```python
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.svm import LinearSVC
from sklearn.svm import SVC
from sklearn.model_selection import train_test_split
```


```python
#Split dataset to train and test 
X_train, X_test, y_train, y_test \
        = train_test_split(dataset_X,dataset_y, test_size=0.2,\
        stratify=dataset_y, random_state=123, shuffle=True)

```


```python
#Logistic Classifier
cls_lgst = LogisticRegression(random_state = 0)
cls_lgst.fit(X_train, y_train)
#predict on test set
# pred_y_logst=cls_lgst.predict(X_test)
```


```python
    
#SV Classifier
# clf_3=SVC(kernel="linear", class_weight="balanced", # penalize
#          probability=True,verbose=2)
# clf_3.fit(X_train,y_train)
# #predict on test set
# pred_y_3=clf_3.predict(X_test)



#Rondom Forest Classifier
clf_RFCls=RandomForestClassifier()
cls2=clf_RFCls.fit(X_train,y_train)
#Predict on test set
# pred_y_RFCls=clf_RFCls.predict(X_test)
```

    /home/hatim/.local/lib/python3.7/site-packages/sklearn/linear_model/_logistic.py:940: ConvergenceWarning: lbfgs failed to converge (status=1):
    STOP: TOTAL NO. of ITERATIONS REACHED LIMIT.
    
    Increase the number of iterations (max_iter) or scale the data as shown in:
        https://scikit-learn.org/stable/modules/preprocessing.html
    Please also refer to the documentation for alternative solver options:
        https://scikit-learn.org/stable/modules/linear_model.html#logistic-regression
      extra_warning_msg=_LOGISTIC_SOLVER_CONVERGENCE_MSG)


# Metrices


```python
from sklearn.metrics import precision_score, recall_score, f1_score
from sklearn.metrics import roc_auc_score

#Prediction:

# pred_y_RFCls=clf_RFCls.predic(X_test)# Rondom Forest Classifier
# pred_y_3=clf_3.predict(X_test)# SCV Classifier
# pred_y_lgst=cls_lgst.predic(X_test)# Logistic 

#############  Scoooooore:

#precision score

print(precision_score(y_test, pred_y_RFCls, average='micro'))
# print(precision_score(y_test, pred_y_3, average='micro'))
print(precision_score(y_test, pred_y_logst, average='micro'))

#recall score
print(recall_score(y_test, pred_y_RFCls, average='micro'))
# print(recall_score(y_test, pred_y_3, average='micro'))
print(recall_score(y_test, pred_y_logst, average='micro'))

#f_score
print(f1_score(y_test, pred_y_RFCls, average='micro'))
# print(f1_score(y_test, pred_y_3, average='micro'))
print(f1_score(y_test, pred_y_logst, average='micro'))




```

    0.9993153330290369
    0.9990871107053826
    0.9993153330290369
    0.9990871107053826
    0.9993153330290369
    0.9990871107053826
    [[9.99928251e-01 7.17488182e-05]
     [9.99795875e-01 2.04125036e-04]
     [9.99701417e-01 2.98583443e-04]
     ...
     [9.98801032e-01 1.19896839e-03]
     [9.99944791e-01 5.52089331e-05]
     [9.99842294e-01 1.57706060e-04]] [[1. 0.]
     [1. 0.]
     [1. 0.]
     ...
     [1. 0.]
     [1. 0.]
     [1. 0.]]



```python
#roc_auc_score
# prob_lgst=cls_lgst.predict_proba(X_test)
# prob_lsgst
# prob_lgst=prob_lgst[:,1]
from sklearn.metrics import roc_auc_score
prob_RFCls=cls2.predict_proba(X_test)
# prob_RFCls[:,0]=(prob_RFCls [:,0]>=.000001).astype("int")
# prob_RFCls[:,1]=(prob_RFCls [:,1]<=.000001).astype("int")

prob_RFCls[:,1]
# sum_both
# prob_RFCls=
# prob_RFCls[:,0]
# predicted[:,1]
# prob_RFCls=[p[1] for p in prob_RFCls]
# prob_RFCls
# y_test
# prob_y_SCV=clf_3.predict_proba(X_test)

# prob_RFCls=[p[0] for p in prob_lgst]
# prob_lgst


# y_test
# len(prob_lgst)
# print (roc_auc_score(y_test,prob_lgst))
# print (roc_auc_score(y_test,prob_RFCls))
# print (roc_auc_score(y_test,prob_y_SCV))


```




    array([0., 0., 0., ..., 0., 0., 0.])




```python
from sklearn.metrics import classification_report

print(classification_report(y_test, y_pred))
```


```python
for clf, label in zip([l_svm, svc, knn, lr], ['LinearSVC', 'SVC', 'KNeighborsClassifier', 'LogisticRegression']):
    print("{} report:".format(label))
    y_pred = clf.predict(X_test)
    print(classification_report(y_test, y_pred))
    print("\n---------------------\n")
```
